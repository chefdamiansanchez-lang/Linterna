package com.datco.linterna

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

private val Bg = Color(0xFF1B2028)
private val CardC = Color(0xFF252C37)
private val Cyan = Color(0xFF00D2FF)
private val Muted = Color(0xFF9AA5B4)
private val Green = Color(0xFF4CD964)
private val Red = Color(0xFFFF5252)

class Torch(ctx: Context) {
    private val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val id: String? = runCatching {
        cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
    }.getOrNull()
    val available get() = id != null
    fun set(on: Boolean) { id?.let { runCatching { cm.setTorchMode(it, on) } } }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = CardC)) {
                var splash by remember { mutableStateOf(true) }
                if (splash) Splash { splash = false } else Home(applicationContext)
            }
        }
    }
}

@Composable
fun Splash(onDone: () -> Unit) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { a.animateTo(1f, tween(900)); delay(1100); onDone() }
    Column(
        Modifier.fillMaxSize().background(Bg).padding(24.dp),
        Arrangement.Center, Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.alpha(a.value).scale(0.8f + 0.2f * a.value).size(96.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF007BC7), Color(0xFF00D2FF)))),
            Alignment.Center
        ) { Text("D", fontSize = 56.sp, fontWeight = FontWeight.Bold, color = Color.White) }
        Spacer(Modifier.height(20.dp))
        Text("DATCO", Modifier.alpha(a.value), color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold, letterSpacing = 8.sp)
        Spacer(Modifier.height(6.dp))
        Text("Desarrollo Avanzado de Tecnologías y Códigos Operativos", Modifier.alpha(a.value), color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(48.dp))
        Text("Diseño de apps... y algo más", Modifier.alpha(a.value), color = Cyan, fontSize = 13.sp)
    }
}

@Composable
fun SensorEffect(ctx: Context, type: Int, onValues: (FloatArray) -> Unit) {
    val cb by rememberUpdatedState(onValues)
    DisposableEffect(type) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val s = sm.getDefaultSensor(type)
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) { cb(e.values) }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        if (s != null) sm.registerListener(l, s, SensorManager.SENSOR_DELAY_GAME)
        onDispose { sm.unregisterListener(l) }
    }
}

@Composable
fun Home(ctx: Context) {
    val torch = remember { Torch(ctx) }
    var tab by remember { mutableStateOf(0) }
    var on by remember { mutableStateOf(false) }
    var sos by remember { mutableStateOf(false) }

    LaunchedEffect(on, sos) {
        if (sos) {
            try {
                while (true) {
                    for (u in listOf(1, 1, 1, 3, 3, 3, 1, 1, 1)) {
                        torch.set(true); delay(u * 250L); torch.set(false); delay(250L)
                    }
                    delay(1000)
                }
            } finally { torch.set(on) }
        } else torch.set(on)
    }
    DisposableEffect(Unit) { onDispose { torch.set(false) } }

    Column(Modifier.fillMaxSize().background(Bg)) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (tab) {
                0 -> Flash(torch.available, on, sos, { sos = false; on = !on }, { sos = !sos; if (sos) on = false })
                1 -> Compass(ctx)
                else -> Level(ctx)
            }
        }
        Row(Modifier.fillMaxWidth().background(CardC).padding(8.dp), Arrangement.SpaceEvenly) {
            listOf("🔦 Linterna", "🧭 Brújula", "📏 Nivel").forEachIndexed { i, t ->
                TextButton(onClick = { tab = i }) {
                    Text(t, color = if (tab == i) Cyan else Muted, fontWeight = if (tab == i) FontWeight.Bold else FontWeight.Normal)
                }
            }
        }
    }
}

@Composable
fun Flash(available: Boolean, on: Boolean, sos: Boolean, onToggle: () -> Unit, onSos: () -> Unit) {
    Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
        Box(
            Modifier.size(180.dp).clip(CircleShape)
                .background(if (on) Color(0xFFFFD54F) else CardC).clickable { onToggle() },
            Alignment.Center
        ) {
            Text(if (on) "ON" else "OFF", fontSize = 36.sp, fontWeight = FontWeight.Bold, color = if (on) Color.Black else Muted)
        }
        Spacer(Modifier.height(32.dp))
        Button(onClick = onSos, colors = ButtonDefaults.buttonColors(containerColor = if (sos) Red else CardC)) {
            Text(if (sos) "Detener SOS" else "SOS", color = Color.White)
        }
        if (!available) {
            Spacer(Modifier.height(16.dp))
            Text("Este dispositivo no tiene flash", color = Muted)
        }
    }
}

@Composable
fun Compass(ctx: Context) {
    var az by remember { mutableStateOf(0f) }
    val rm = remember { FloatArray(9) }
    val o = remember { FloatArray(3) }
    SensorEffect(ctx, Sensor.TYPE_ROTATION_VECTOR) { v ->
        SensorManager.getRotationMatrixFromVector(rm, v)
        SensorManager.getOrientation(rm, o)
        val deg = ((Math.toDegrees(o[0].toDouble()) + 360.0) % 360.0).toFloat()
        var d = deg - az
        if (d > 180f) d -= 360f
        if (d < -180f) d += 360f
        az = (az + d * 0.15f + 360f) % 360f
    }
    val names = listOf("N", "NE", "E", "SE", "S", "SO", "O", "NO")
    val card = names[((az + 22.5f) / 45f).toInt() % 8]
    Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
        Text("${az.toInt()}°  $card", color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("▼", color = Red, fontSize = 22.sp)
        Box(Modifier.size(280.dp).graphicsLayer { rotationZ = -az }, Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val r = size.minDimension / 2
                drawCircle(CardC, r)
                drawCircle(Cyan, r, style = Stroke(4f))
                for (i in 0 until 72) {
                    val ang = Math.toRadians(i * 5.0)
                    val len = if (i % 6 == 0) 24f else 10f
                    val s = Offset(center.x + (r - len) * sin(ang).toFloat(), center.y - (r - len) * cos(ang).toFloat())
                    val e = Offset(center.x + r * sin(ang).toFloat(), center.y - r * cos(ang).toFloat())
                    drawLine(Muted, s, e, 2f)
                }
            }
            Text("N", Modifier.align(Alignment.TopCenter).padding(top = 30.dp), color = Red, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("S", Modifier.align(Alignment.BottomCenter).padding(bottom = 30.dp), color = Color.White, fontSize = 20.sp)
            Text("O", Modifier.align(Alignment.CenterStart).padding(start = 30.dp), color = Color.White, fontSize = 20.sp)
            Text("E", Modifier.align(Alignment.CenterEnd).padding(end = 30.dp), color = Color.White, fontSize = 20.sp)
        }
    }
}

@Composable
fun Level(ctx: Context) {
    var ax by remember { mutableStateOf(0f) }
    var ay by remember { mutableStateOf(0f) }
    SensorEffect(ctx, Sensor.TYPE_ACCELEROMETER) { v ->
        val g = sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]).coerceAtLeast(0.1f)
        val tx = Math.toDegrees(asin((v[0] / g).coerceIn(-1f, 1f)).toDouble()).toFloat()
        val ty = Math.toDegrees(asin((v[1] / g).coerceIn(-1f, 1f)).toDouble()).toFloat()
        ax += (tx - ax) * 0.2f
        ay += (ty - ay) * 0.2f
    }
    val ok = abs(ax) < 0.6f && abs(ay) < 0.6f
    val col = if (ok) Green else Cyan
    Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
        Text(if (ok) "¡Nivelado!" else "Apoyá el celular plano", color = if (ok) Green else Muted, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        Box(Modifier.size(280.dp)) {
            Canvas(Modifier.fillMaxSize()) {
                val r = size.minDimension / 2
                drawCircle(CardC, r)
                drawCircle(col, r, style = Stroke(4f))
                drawLine(Muted, Offset(center.x - r, center.y), Offset(center.x + r, center.y), 1.5f)
                drawLine(Muted, Offset(center.x, center.y - r), Offset(center.x, center.y + r), 1.5f)
                drawCircle(col, r * 0.18f, style = Stroke(3f))
                val maxD = r * 0.82f
                val k = maxD / 30f
                var dx = ax * k
                var dy = -ay * k
                val dist = sqrt(dx * dx + dy * dy)
                if (dist > maxD) { dx *= maxD / dist; dy *= maxD / dist }
                drawCircle(col.copy(alpha = 0.85f), r * 0.14f, Offset(center.x + dx, center.y + dy))
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("X: ${"%.1f".format(ax)}°    Y: ${"%.1f".format(ay)}°", color = Color.White, fontSize = 20.sp)
    }
}
